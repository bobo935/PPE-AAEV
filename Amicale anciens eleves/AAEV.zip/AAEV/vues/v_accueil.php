<div id="accueil">
AAEV, Amicale des Anciens de Voillaume
</div>
