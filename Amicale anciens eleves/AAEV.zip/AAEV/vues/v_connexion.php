<html>
<body>
<form method="post" action="index.php?uc=administrer&action=traitement">
   <p>
       <label for="pseudo">Votre pseudo :</label>
       <input type="text" name="pseudo" id="pseudo" />
       
       <br />
       <label for="pass">Votre mot de passe :</label>
       <input type="password" name="passe" id="pass" />
       <input type="submit" value="Envoyer" />
   </p>
</form>
</body>
</html>