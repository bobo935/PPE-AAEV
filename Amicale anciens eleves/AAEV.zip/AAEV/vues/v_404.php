<div>
    <h1>Page introuvable</h1>
     <p> <?php // echo $message; ?></p> 
</div> 
