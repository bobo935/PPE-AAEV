<div id="bandeau">
<!-- Images En-t�te -->
<!--<img src="images/menuGauche.gif"	alt="Choisir" title="Choisir"/>-->
</div>
<!--  Menu haut-->
<ul id="menu">
	<li><a href="index.php?uc=accueil"> Accueil </a></li>
	<li><a href="index.php?uc=voirOffres&action=voirLesOffres"> Voir les offres </a></li>
	<!--<li><a href="index.php?uc=administrer"> Administrer </a></li>-->
        <li><a href="index.php?uc=administrer&action=deconnexion"> Déconnexion </a></li>
</ul>
